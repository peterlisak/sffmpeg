function dmos=rred2dmos(rred)
dmos=16.4769+9.7111*log(1+rred/0.6444);